# E-Commerce Website
online shopping website

## Installation

```bash
npm install
```

## Environment Variables (.env)
DATABASE_USER
DATABASE_PASSWORD
DBNAME
SESSION_SECRET
PEPPER
SALT_ROUNDS
PORT

## How to Run

```bash
npm run start
```
